# -*- coding: utf-8 -*-
"""
Safe/stable refactor of the framework from the uploaded project.

This build intentionally performs LOCAL format validation only.
It does not connect to third-party account/login services.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from core.runner import BulkRunner, RunnerConfig, format_progress
from utils.file_io import iter_combos, parse_combo, save_result

BASE = Path(__file__).resolve().parent
RES = BASE / "res"


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def banner():
    clear()
    print("=" * 72)
    print("  COMBO FRAMEWORK - FIXED / SAFE LOCAL BUILD")
    print("  Optimized preset: Windows 2 vCPU / 4 GB RAM")
    print("=" * 72)
    print()


def local_check(account: str, password: str) -> dict:
    """Local-only validation. No network traffic."""
    account = (account or "").strip()
    password = (password or "").strip()
    if not account or not password:
        return {"status": "INVALID_FORMAT", "account": account, "password": password,
                "detail": "empty account/password"}

    # Basic sanity checks only; this is not an authentication check.
    if len(account) > 256 or len(password) > 256:
        return {"status": "INVALID_FORMAT", "account": account, "password": password,
                "detail": "field too long"}
    if any(ch in account for ch in "\r\n") or any(ch in password for ch in "\r\n"):
        return {"status": "INVALID_FORMAT", "account": account, "password": password,
                "detail": "newline in field"}

    return {"status": "VALID_FORMAT", "account": account, "password": password,
            "detail": "local syntax only"}


def run_one():
    raw = input("Nhập dòng account|password hoặc account:password: ").strip()
    item = parse_combo(raw)
    if item is None:
        print("Sai định dạng.")
        return
    account, password = item
    r = local_check(account, password)
    print(r["status"], "-", r["detail"])


def run_file():
    raw_path = input("Đường dẫn file combo: ").strip().strip('"')
    path = Path(raw_path)
    if not path.is_file():
        print("Không tìm thấy file:", path)
        return

    raw_threads = input("Threads [mặc định 6, khuyên 4-8, tối đa 12]: ").strip()
    try:
        workers = int(raw_threads) if raw_threads else 6
    except ValueError:
        workers = 6

    cfg = RunnerConfig(workers=workers, max_workers=12, max_inflight_factor=3)

    # Stream the file instead of loading everything into RAM.
    runner = BulkRunner(cfg)
    RES.mkdir(parents=True, exist_ok=True)

    def on_result(result):
        save_result(
            RES / ("valid_format.txt" if result["status"] == "VALID_FORMAT"
                   else "invalid_format.txt"),
            result["account"],
            result["password"],
            result["detail"],
        )

    def on_progress(snapshot):
        print("\r" + format_progress(snapshot), end="", flush=True)

    try:
        summary = runner.run(
            items=iter_combos(path),
            worker=local_check,
            on_result=on_result,
            on_progress=on_progress,
        )
    except KeyboardInterrupt:
        runner.stop()
        print("\nĐã yêu cầu dừng.")
        return

    print()
    print("Hoàn tất:", summary)
    print("Kết quả local lưu tại:", RES)


def main():
    while True:
        banner()
        print("[1] Kiểm tra 1 dòng (local format)")
        print("[2] Đọc file combo (local format)")
        print("[0] Thoát")
        choice = input("\nChọn: ").strip()
        if choice == "1":
            run_one()
        elif choice == "2":
            run_file()
        elif choice == "0":
            break
        else:
            print("Lựa chọn không hợp lệ.")
        try:
            input("\nEnter để tiếp tục...")
        except (EOFError, KeyboardInterrupt):
            break


if __name__ == "__main__":
    main()
