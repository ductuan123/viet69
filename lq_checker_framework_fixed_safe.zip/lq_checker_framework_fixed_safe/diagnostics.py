# -*- coding: utf-8 -*-
from pathlib import Path
import platform
import sys
import py_compile

BASE = Path(__file__).resolve().parent

def main():
    print("Python:", sys.version.split()[0])
    print("OS:", platform.platform())
    print("Folder:", BASE)
    files = [
        BASE / "main.py",
        BASE / "core" / "runner.py",
        BASE / "utils" / "file_io.py",
    ]
    ok = True
    for p in files:
        try:
            py_compile.compile(str(p), doraise=True)
            print("OK  ", p.relative_to(BASE))
        except Exception as e:
            ok = False
            print("FAIL", p.relative_to(BASE), e)
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
