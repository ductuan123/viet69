# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
from threading import Lock
from typing import Iterator, Optional

_save_lock = Lock()


def parse_combo(line: str) -> Optional[tuple[str, str]]:
    line = (line or "").strip()
    if not line or line.startswith("#"):
        return None

    # Preserve only the first separator so passwords can contain the other one.
    if "|" in line:
        a, p = line.split("|", 1)
    elif ":" in line:
        a, p = line.split(":", 1)
    else:
        return None

    a, p = a.strip(), p.strip()
    if not a or not p:
        return None
    return a, p


def iter_combos(path: Path) -> Iterator[tuple[str, str]]:
    # Streaming reader: very large files do not need to be loaded into RAM.
    with Path(path).open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            item = parse_combo(line)
            if item is not None:
                yield item


def save_result(path: Path, account: str, password: str, detail: str = "") -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    safe_detail = (detail or "").replace("\r", " ").replace("\n", " ")
    with _save_lock:
        with path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"{account}|{password}|{safe_detail}\n")
