# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from threading import Event, Lock
from time import monotonic
from typing import Callable, Iterable, Dict, Any, Optional


@dataclass
class RunnerConfig:
    workers: int = 6
    max_workers: int = 12
    max_inflight_factor: int = 3
    progress_interval: float = 0.25

    def normalized_workers(self) -> int:
        # Windows 2 vCPU / 4 GB: keep the framework modest and predictable.
        return max(1, min(int(self.workers or 1), int(self.max_workers or 12)))


class BulkRunner:
    """
    Bounded-inflight thread runner.

    Important fixes compared with the uploaded framework:
    - never queues the whole input at once;
    - every Future is consumed, so worker exceptions are not silently lost;
    - progress state is owned by this object (no nested-scope global bug);
    - counters update in a finally-safe path;
    - Stop is cooperative.
    """
    def __init__(self, config: RunnerConfig):
        self.config = config
        self.stop_event = Event()
        self._lock = Lock()

    def stop(self) -> None:
        self.stop_event.set()

    def run(
        self,
        items: Iterable[tuple[str, str]],
        worker: Callable[[str, str], Dict[str, Any]],
        on_result: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_progress: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Dict[str, int]:
        workers = self.config.normalized_workers()
        max_inflight = max(workers, workers * max(1, self.config.max_inflight_factor))

        stats = {
            "submitted": 0,
            "done": 0,
            "ok": 0,
            "invalid": 0,
            "error": 0,
            "workers": workers,
        }
        started = monotonic()
        last_progress = 0.0

        iterator = iter(items)
        exhausted = False
        pending = set()

        def submit_one(executor):
            nonlocal exhausted
            if exhausted or self.stop_event.is_set():
                return False
            try:
                account, password = next(iterator)
            except StopIteration:
                exhausted = True
                return False
            fut = executor.submit(worker, account, password)
            pending.add(fut)
            stats["submitted"] += 1
            return True

        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="safe-worker") as executor:
            while len(pending) < max_inflight and submit_one(executor):
                pass

            while pending:
                if self.stop_event.is_set():
                    for fut in pending:
                        fut.cancel()
                    break

                done_set, _ = wait(pending, timeout=0.20, return_when=FIRST_COMPLETED)
                if not done_set:
                    now = monotonic()
                    if on_progress and now - last_progress >= self.config.progress_interval:
                        snap = dict(stats)
                        snap["elapsed"] = now - started
                        snap["inflight"] = len(pending)
                        on_progress(snap)
                        last_progress = now
                    continue

                for fut in done_set:
                    pending.remove(fut)
                    try:
                        result = fut.result()
                    except Exception as exc:
                        result = {
                            "status": "ERROR",
                            "account": "",
                            "password": "",
                            "detail": f"{type(exc).__name__}: {exc}",
                        }

                    with self._lock:
                        stats["done"] += 1
                        status = result.get("status")
                        if status == "VALID_FORMAT":
                            stats["ok"] += 1
                        elif status == "INVALID_FORMAT":
                            stats["invalid"] += 1
                        else:
                            stats["error"] += 1

                    if on_result:
                        try:
                            on_result(result)
                        except Exception:
                            # Result persistence must never kill the worker loop.
                            with self._lock:
                                stats["error"] += 1

                    while len(pending) < max_inflight and submit_one(executor):
                        pass

                now = monotonic()
                if on_progress and (
                    now - last_progress >= self.config.progress_interval
                    or (exhausted and not pending)
                ):
                    snap = dict(stats)
                    snap["elapsed"] = now - started
                    snap["inflight"] = len(pending)
                    on_progress(snap)
                    last_progress = now

        return stats


def format_progress(s: Dict[str, Any]) -> str:
    elapsed = max(float(s.get("elapsed", 0.0)), 0.001)
    done = int(s.get("done", 0))
    rate = done / elapsed
    return (
        f"Done={done}  OK={s.get('ok', 0)}  "
        f"Invalid={s.get('invalid', 0)}  Err={s.get('error', 0)}  "
        f"InFlight={s.get('inflight', 0)}  "
        f"Rate={rate:.1f}/s  Workers={s.get('workers', 0)}"
    )
