LQ CHECKER FRAMEWORK - FIXED SAFE BUILD
=======================================

Mục đích
--------
Bản này sửa/refactor phần framework của project upload:
- thread/future
- progress
- đọc file lớn
- lưu kết quả
- giới hạn RAM/CPU cho Windows 2 vCPU / 4 GB

Lưu ý an toàn
-------------
Bản này KHÔNG thực hiện đăng nhập/kiểm tra tài khoản trên dịch vụ bên thứ ba.
Hàm xử lý chỉ kiểm tra cú pháp local của dòng account|password / account:password.

Các lỗi cụ thể tìm thấy trong source upload
-------------------------------------------
1) Nested worker đọc rồi gán _LAST_PROGRESS_RENDER nhưng không khai báo scope phù hợp.
   Điều này có thể tạo UnboundLocalError trong worker và làm progress nhìn như bị đứng.

2) ThreadPoolExecutor.map(...) được tạo nhưng iterator kết quả không được consume.
   Exception phát sinh bên trong worker vì vậy có thể bị ẩn, rất khó biết tool đang lỗi gì.

3) Có pool HTTP 500 worker và giới hạn kết nối 100 socket.
   Với máy Windows 2 vCPU / 4 GB đây là mức quá cao, dễ tốn RAM, context switch và tài nguyên socket.

4) Batch cũ có xu hướng tạo/submission lượng công việc lớn cùng lúc.
   Bản này giữ số task đang bay ở workers*3, nên RAM ổn định hơn.

5) Progress cuối cũ có chỗ truyền done=total cố định thay vì dùng số thực tế.
   Bản này chỉ báo số Future đã được thu kết quả thật sự.

Preset khuyến nghị cho Win 2 vCPU / 4 GB
----------------------------------------
- mặc định: 6 worker
- khuyên dùng: 4-8 worker
- hard cap trong build này: 12 worker
- in-flight: worker * 3
- progress: tối đa khoảng 4 lần/giây

Chạy
----
python diagnostics.py
python main.py

Không cần cài package ngoài Python chuẩn.
