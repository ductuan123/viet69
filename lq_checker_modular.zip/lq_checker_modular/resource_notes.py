# -*- coding: utf-8 -*-
"""Resource-related constants/documentation.

This module intentionally does not alter login/checking concurrency.
"""
PROGRESS_RENDER_INTERVAL = 0.25

# Keep terminal rendering modest: UI redraws cost CPU at high completion rates.
# Heavy OCR dependencies are lazy-loaded in main.py.
# Large skin data is lazy-loaded from skin_catalog.py only when needed.
