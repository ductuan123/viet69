# -*- coding: utf-8 -*-
"""Lightweight dependency/config diagnostics. Does not perform account checks."""
from __future__ import annotations

import importlib.util
import platform
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent

DEPENDENCIES = {
    "requests": "requests",
    "colorama": "colorama",
    "pystyle": "pystyle",
    "Pillow (optional CAPTCHA fallback)": "PIL",
    "NumPy (optional CAPTCHA OCR)": "numpy",
    "OpenCV (optional CAPTCHA OCR)": "cv2",
    "ddddocr (optional CAPTCHA OCR)": "ddddocr",
}


def main() -> int:
    print("=== LQ Checker diagnostics ===")
    print("Python :", sys.version.split()[0])
    print("OS     :", platform.platform())
    print("Folder :", BASE)
    print()

    required_missing = []
    for label, module in DEPENDENCIES.items():
        ok = importlib.util.find_spec(module) is not None
        print(f"{'OK  ' if ok else 'MISS'} {label}")
        if not ok and module in {"requests", "colorama"}:
            required_missing.append(module)

    print()
    for filename in ("main.py", "skin_catalog.py", "resource_notes.py"):
        p = BASE / filename
        print(f"{'OK  ' if p.is_file() else 'MISS'} {filename}")

    if required_missing:
        print("\nThiếu dependency bắt buộc:", ", ".join(required_missing))
        return 1
    print("\nCác dependency bắt buộc cơ bản đã có.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
