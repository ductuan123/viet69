LQ CHECKER - MODULAR / RESOURCE CLEANUP
======================================

Files
-----
main.py          : application/check flow (existing behavior preserved)
skin_catalog.py  : large static skin database + skin classification helpers
resource_notes.py: notes/constants related to resource usage

Resource changes
----------------
1. OpenCV / NumPy / Pillow / ddddocr are no longer imported at startup.
   They load only when CAPTCHA solving is actually invoked.
2. The large skin catalog is no longer embedded in main.py.
   It is lazy-imported only when _classify_skins() is needed.
3. Terminal progress rendering is throttled to about 4 redraws/second.
   Check result logic and HIT/BAD classification are not changed by this.
4. The existing account-login/check concurrency/retry behavior is intentionally preserved.

Run
---
python main.py

Keep main.py and skin_catalog.py in the same directory.
